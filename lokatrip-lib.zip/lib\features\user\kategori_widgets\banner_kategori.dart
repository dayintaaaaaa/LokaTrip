
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../core/app_color.dart';

class BannerKategori extends StatelessWidget {
  final PromoKategori promo;
  final VoidCallback? onTombol;

  const BannerKategori({
    super.key,
    required this.promo,
    this.onTombol,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: [AppColor.ungu, const Color(0xFF6A74BE)],
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (promo.periode != null) ...[
                  Text(
                    promo.periode!,
                    style: GoogleFonts.manrope(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      color: AppColor.putih,
                    ),
                  ),
                  const SizedBox(height: 8),
                ],

                Text(
                  promo.judul,
                  style: GoogleFonts.outfit(
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                    color: AppColor.putih,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  promo.deskripsi,
                  style: GoogleFonts.manrope(
                    fontSize: 11,
                    color: AppColor.putih.withValues(alpha: 0.9),
                  ),
                ),

                if (promo.kode != null) ...[
                  const SizedBox(height: 10),
                  _barisKode(context),
                ],
              ],
            ),
          ),

          if (promo.tombol != null) ...[
            const SizedBox(width: 12),
            _tombol(context),
          ] else if (promo.ikon != null) ...[
            const SizedBox(width: 12),
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: AppColor.putih.withValues(alpha: 0.18),
                shape: BoxShape.circle,
              ),
              child: Icon(
                promo.ikon,
                size: 20,
                color: AppColor.putih,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Future<void> _salin(BuildContext context, String kode) async {
    await Clipboard.setData(ClipboardData(text: kode));
    if (!context.mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Kode $kode disalin'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Widget _barisKode(BuildContext context) {
    final kode = promo.kode!;
    final kotakPutih = promo.awalanKode != null;
    final linkSalin =
        !kotakPutih && promo.tombol == null && promo.catatan == null;

    return Row(
      children: [
        if (kotakPutih) ...[
          Text(
            promo.awalanKode!,
            style: GoogleFonts.manrope(
              fontSize: 10,
              fontWeight: FontWeight.w600,
              color: AppColor.putih,
            ),
          ),
          const SizedBox(width: 8),
        ],
        Flexible(
          child: Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 7,
            ),
            decoration: BoxDecoration(
              color: kotakPutih
                  ? AppColor.putih
                  : AppColor.kuning.withValues(alpha: 0.18),
              borderRadius: BorderRadius.circular(8),
              border: kotakPutih
                  ? null
                  : Border.all(color: AppColor.kuning),
            ),
            child: Text(
              kode,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.manrope(
                fontSize: 12,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.8,
                color: kotakPutih ? AppColor.ungu : AppColor.kuning,
              ),
            ),
          ),
        ),
        const Spacer(),
        if (promo.catatan != null)
          Text(
            promo.catatan!,
            style: GoogleFonts.manrope(
              fontSize: 10,
              fontWeight: FontWeight.w700,
              color: AppColor.putih,
              decoration: TextDecoration.underline,
              decorationColor: AppColor.putih,
            ),
          )
        else if (linkSalin)
          GestureDetector(
            onTap: () => _salin(context, kode),
            child: Row(
              children: [
                Icon(
                  Icons.copy_rounded,
                  size: 13,
                  color: AppColor.putih,
                ),
                const SizedBox(width: 4),
                Text(
                  'Salin Kode',
                  style: GoogleFonts.manrope(
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    color: AppColor.putih,
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }

  Widget _tombol(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (onTombol != null) {
          onTombol!();
          return;
        }

        final kode = promo.kode;
        if (kode != null) {
          _salin(context, kode);
          return;
        }

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Promo berhasil diklaim'),
            duration: Duration(seconds: 2),
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: 18,
          vertical: 10,
        ),
        decoration: BoxDecoration(
          color: AppColor.putih,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(
          promo.tombol!,
          style: GoogleFonts.manrope(
            fontSize: 12,
            fontWeight: FontWeight.w800,
            color: AppColor.ungu,
          ),
        ),
      ),
    );
  }
}
