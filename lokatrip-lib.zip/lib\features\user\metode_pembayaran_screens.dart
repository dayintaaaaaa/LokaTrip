
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../core/app_color.dart';

class BannerKategori extends StatelessWidget {
  final String judul;
  final String deskripsi;
  final IconData? ikon;

  const BannerKategori({
    super.key,
    required this.judul,
    required this.deskripsi,
    this.ikon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: [
            AppColor.ungu,
            const Color(0xFF6A74BE),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  judul,
                  style: GoogleFonts.outfit(
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                    color: AppColor.putih,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  deskripsi,
                  style: GoogleFonts.manrope(
                    fontSize: 11,
                    color: AppColor.putih.withValues(alpha: 0.9),
                  ),
                ),
              ],
            ),
          ),

          if (ikon != null) ...[
            const SizedBox(width: 12),
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: AppColor.putih.withValues(alpha: 0.18),
                shape: BoxShape.circle,
              ),
              child: Icon(
                ikon,
                size: 20,
                color: AppColor.putih,
              ),
            ),
          ],
        ],
      ),
    );
  }
}
